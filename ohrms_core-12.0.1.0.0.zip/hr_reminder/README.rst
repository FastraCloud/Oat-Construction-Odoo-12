Open HRMS Reminders Todo V11
============================

HR Reminder For OHRMS

Depends
=======
[hr] addon Odoo

Tech
====
* [Python] - Models
* [XML] - Odoo views

Installation
============
- www.odoo.com/documentation/10.0/setup/install.html
- Install our custom addon


Bug Tracker
===========
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Credits
=======
* Cybrosys Techno Solutions <https://www.cybrosys.com>

Author
------

Developer: Treesa Maria Jude @ cybrosys, treesa@cybrosys.in

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.
